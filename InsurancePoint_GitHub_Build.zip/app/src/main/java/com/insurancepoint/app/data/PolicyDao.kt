package com.insurancepoint.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PolicyDao {
    @Query("SELECT * FROM policies ORDER BY expiryDate ASC")
    fun observePolicies(): Flow<List<PolicyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(policy: PolicyEntity)

    @Query("SELECT * FROM policies WHERE synced = 0")
    suspend fun pendingSync(): List<PolicyEntity>

    @Query("UPDATE policies SET synced = 1 WHERE policyId = :id")
    suspend fun markSynced(id: String)
}
