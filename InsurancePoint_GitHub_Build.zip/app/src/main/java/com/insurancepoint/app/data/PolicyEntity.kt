package com.insurancepoint.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "policies")
data class PolicyEntity(
    @PrimaryKey val policyId: String,
    val customerName: String,
    val vehicleNumber: String,
    val insurerName: String,
    val expiryDate: String,
    val documentUrl: String? = null,
    val synced: Boolean = false
)
