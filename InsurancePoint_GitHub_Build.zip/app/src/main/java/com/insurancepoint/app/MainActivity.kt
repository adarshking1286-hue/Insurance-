package com.insurancepoint.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF102A43)
private val Blue = Color(0xFF1976D2)
private val Pale = Color(0xFFF2F6FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InsurancePointApp() }
    }
}

@Composable
fun InsurancePointApp() {
    var page by remember { mutableStateOf("welcome") }
    var role by remember { mutableStateOf("Agent") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Navy, secondary = Blue, background = Pale
    )) {
        Surface(Modifier.fillMaxSize(), color = Pale) {
            when (page) {
                "welcome" -> WelcomeScreen(
                    onAgent = { role = "Agent"; page = "login" },
                    onCustomer = { role = "Customer"; page = "login" }
                )
                "login" -> LoginScreen(
                    role = role, email = email, password = password,
                    onEmail = { email = it }, onPassword = { password = it },
                    onLogin = { page = "dashboard" },
                    onRegister = { page = "register" },
                    onBack = { page = "welcome" }
                )
                "register" -> RegisterScreen(
                    onBack = { page = "login" },
                    onComplete = { page = "dashboard" }
                )
                else -> DashboardScreen(role = role, onLogout = { page = "welcome" })
            }
        }
    }
}

@Composable
private fun WelcomeScreen(onAgent: () -> Unit, onCustomer: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Navy).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("INSURANCE POINT", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Your vehicle insurance, simplified", color = Color(0xFFD9E8F5), modifier = Modifier.padding(top = 8.dp, bottom = 36.dp))
        Button(onClick = onAgent, modifier = Modifier.fillMaxWidth()) { Text("Agent Login") }
        OutlinedButton(onClick = onCustomer, modifier = Modifier.fillMaxWidth()) { Text("Customer Login / Register") }
        Text("Secure insurance management", color = Color.White.copy(alpha = .75f), modifier = Modifier.padding(top = 28.dp))
    }
}

@Composable
private fun LoginScreen(
    role: String, email: String, password: String,
    onEmail: (String) -> Unit, onPassword: (String) -> Unit,
    onLogin: () -> Unit, onRegister: () -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Welcome back", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("$role sign in", color = Blue, modifier = Modifier.padding(bottom = 24.dp))
        OutlinedTextField(value = email, onValueChange = onEmail, label = { Text("Email address") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = password, onValueChange = onPassword, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
        Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) { Text("Sign in") }
        if (role == "Customer") TextButton(onClick = onRegister) { Text("Create customer account") }
        TextButton(onClick = onBack) { Text("Back") }
        Text("Demo screen only: connect Firebase before using real accounts.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun RegisterScreen(onBack: () -> Unit, onComplete: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Customer registration", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("Mobile number") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick = onComplete, modifier = Modifier.fillMaxWidth()) { Text("Create account") }
        TextButton(onClick = onBack) { Text("Back to login") }
        Text("Registration UI only. Firebase account creation is not connected yet.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun DashboardScreen(role: String, onLogout: () -> Unit) {
    var selected by remember { mutableStateOf("Overview") }
    Scaffold(
        topBar = {
            TopAppBarPlaceholder(title = "Insurance Point", onLogout = onLogout)
        },
        bottomBar = {
            NavigationBar {
                listOf("Overview", "Policies", "Customers", "Profile").forEach { item ->
                    NavigationBarItem(
                        selected = selected == item,
                        onClick = { selected = item },
                        icon = { Text(when(item) { "Overview" -> "⌂"; "Policies" -> "▣"; "Customers" -> "♙"; else -> "⚙" }) },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            item {
                Text("Hello, $role!", color = Navy, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Here is your insurance workspace.", color = Color.Gray)
                Spacer(Modifier.height(18.dp))
                if (role == "Agent") {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("Customers", "0", Modifier.weight(1f))
                        StatCard("Active policies", "0", Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("Renewals due", "0", Modifier.weight(1f))
                        StatCard("This month's business", "₹0", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = { selected = "Customers" }, modifier = Modifier.fillMaxWidth()) { Text("＋ Add customer") }
                    OutlinedButton(onClick = { selected = "Policies" }, modifier = Modifier.fillMaxWidth()) { Text("＋ Add insurance policy") }
                } else {
                    StatCard("My active policies", "0", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    InfoCard("My policies", "Your active and expired vehicle policies will appear here.")
                    InfoCard("Renewal requests", "Request help from your agent when a policy is nearing expiry.")
                }
                Spacer(Modifier.height(18.dp))
                InfoCard(selected, when(selected) {
                    "Policies" -> "Policy records will be displayed here after database setup."
                    "Customers" -> "Customer records and customer creation will appear here."
                    "Profile" -> "Account settings will appear here."
                    else -> "Your latest activity will appear here."
                })
            }
        }
    }
}

@Composable
private fun TopAppBarPlaceholder(title: String, onLogout: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f), color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        TextButton(onClick = onLogout) { Text("Logout") }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier.padding(vertical = 5.dp), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Blue)
            Text(label, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Navy)
            Text(body, color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
        }
    }
}
