# Insurance Point Android starter

This is a starter Android Studio project for the Insurance Point vehicle-insurance app.

## Included in this ZIP
- Kotlin + Jetpack Compose starter UI
- Agent and Customer entry screens
- Customer registration screen (UI prototype)
- Agent/customer dashboard prototypes
- Room database policy entity and DAO for offline storage
- Firebase Auth, Firestore and Storage dependencies prepared

## Important: prototype status
This ZIP is source code, not a finished APK. Login, registration, policy creation, uploads, WhatsApp actions, cloud sync, reminders, and reports are not connected yet. The current buttons demonstrate the screen flow only. Do not enter real customer information until authentication, database security rules, and privacy protections are implemented.

## Build in Android Studio
1. Install Android Studio on a computer and open this `InsurancePoint` folder.
2. Let Gradle sync complete. Use JDK 17.
3. Create a Firebase project at https://console.firebase.google.com/.
4. Add an Android app with package name `com.insurancepoint.app`.
5. Download `google-services.json` and put it inside the `app/` folder.
6. In Firebase Authentication, enable Email/Password sign-in.
7. Set up Firestore and Storage. Add restrictive security rules so customers can read only their own records and agents have authorized access.
8. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Compatibility
- Minimum Android version: Android 10 (API 29)
- Compile/target SDK: 35
- App ID: `com.insurancepoint.app`

## Next development steps
1. Implement Firebase Auth and role-based authorization.
2. Store user profiles with a role (`agent` or `customer`) and customer ownership links.
3. Add policy/customer CRUD screens and validation.
4. Implement Room repository + WorkManager sync with conflict handling.
5. Securely upload policy documents to Firebase Storage.
6. Add renewal notifications and WhatsApp share intents.
7. Test access control, backups, offline behavior, and APK installation.


## Build APK using GitHub from an Android phone
This repository includes `.github/workflows/build-apk.yml` for a cloud build. You do not need Android Studio on your phone.

1. On GitHub, create a new repository named `InsurancePoint`.
2. Extract this ZIP on your phone if your file manager supports it.
3. Upload the contents of the extracted folder to the repository root (not the outer folder itself). Include the hidden `.github/workflows/build-apk.yml` file. If GitHub mobile hides dot-folders, use GitHub in Chrome with Desktop site enabled, or create the workflow file separately.
4. Open the repository's Actions tab. Select **Build Insurance Point APK** and tap **Run workflow** (or wait for the push-triggered build).
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, scroll to Artifacts, and download `InsurancePoint-debug-apk`.
7. Extract that downloaded artifact ZIP; it contains `app-debug.apk`. Install it on your phone after allowing installs from that source.

## Important limitations
This workflow builds the current starter/demo app, not a fully finished insurance system. Firebase login, live cloud sync, policy management, reminders, document uploads, and WhatsApp actions are not implemented yet. The login buttons currently demonstrate screen navigation only. Firebase project configuration and secure access rules must be added before handling real customer data. This produces a debug APK, not a Play Store release.
